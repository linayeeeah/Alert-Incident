"use client";

import { useMemo, useState } from "react";

type Occurrence = { id: string; value: string; triggered: string; entity: string; breach: string; recovered: string; duration: string; signal: "Active" | "Recovered" };
type AlertGroup = {
  title: string;
  application: string;
  assignment: string;
  source: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  priority: "P1" | "P2" | "P3" | "P4";
  priorityReason: string;
  investigation: "New" | "Acknowledged" | "Investigating" | "Suppression Requested";
  owner: string;
  incident?: { id: string; state: string };
  repeatWindow: string;
  firstSeen: string;
  suppressionCandidate?: boolean;
  occurrences: Occurrence[];
};

const alerts: AlertGroup[] = [
  {
    title: "CyberArk Component Health",
    application: "CyberArk",
    assignment: "Cyber PAM Support",
    source: "CyberSplunk",
    severity: "Critical",
    priority: "P1",
    priorityReason: "Critical application · active for 47 minutes · 5 occurrences · no owner assigned",
    investigation: "New",
    owner: "Unassigned",
    incident: { id: "INC0098421", state: "In Progress" },
    repeatWindow: "5 in 2h",
    firstSeen: "2 hr ago",
    occurrences: [
      { id: "ALT-92841", value: "Component unavailable", triggered: "22 Jul 2026, 21:47", entity: "cyberark-prod-02", breach: "Health check failed", recovered: "—", duration: "47 min", signal: "Active" },
      { id: "ALT-92813", value: "Health check timed out", triggered: "22 Jul 2026, 21:32", entity: "cyberark-prod-02", breach: "Timeout > 30s", recovered: "21:38", duration: "6 min", signal: "Recovered" },
      { id: "ALT-92791", value: "Component unavailable", triggered: "22 Jul 2026, 21:16", entity: "cyberark-prod-02", breach: "Health check failed", recovered: "21:24", duration: "8 min", signal: "Recovered" },
      { id: "ALT-92766", value: "Health check timed out", triggered: "22 Jul 2026, 20:58", entity: "cyberark-prod-02", breach: "Timeout > 30s", recovered: "21:04", duration: "6 min", signal: "Recovered" },
      { id: "ALT-92632", value: "Component unavailable", triggered: "22 Jul 2026, 19:41", entity: "cyberark-prod-02", breach: "Health check failed", recovered: "19:55", duration: "14 min", signal: "Recovered" },
    ],
  },
  {
    title: "Illumio VEN Status Check",
    application: "Illumio",
    assignment: "Network Security Ops",
    source: "ITSI",
    severity: "High",
    priority: "P2",
    priorityReason: "High severity · production entity offline · recurring within four hours",
    investigation: "Investigating",
    owner: "M. Chen",
    incident: { id: "INC0098396", state: "Investigating" },
    repeatWindow: "3 in 4h",
    firstSeen: "4 hr ago",
    occurrences: [
      { id: "ALT-92805", value: "VEN offline", triggered: "22 Jul 2026, 21:26", entity: "gcp-prod-app-17", breach: "Heartbeat missing", recovered: "—", duration: "1 hr 8 min", signal: "Active" },
      { id: "ALT-92688", value: "Heartbeat missing", triggered: "22 Jul 2026, 20:04", entity: "gcp-prod-app-17", breach: "3 missed heartbeats", recovered: "20:18", duration: "14 min", signal: "Recovered" },
      { id: "ALT-92510", value: "VEN offline", triggered: "22 Jul 2026, 17:39", entity: "gcp-prod-app-17", breach: "Heartbeat missing", recovered: "18:03", duration: "24 min", signal: "Recovered" },
    ],
  },
  {
    title: "HashiVault Storage Utilisation",
    application: "HashiVault",
    assignment: "Secrets Platform",
    source: "AppDynamics",
    severity: "Medium",
    priority: "P3",
    priorityReason: "Medium severity · value remains above threshold · application owner assigned",
    investigation: "Acknowledged",
    owner: "A. Singh",
    incident: { id: "INC0098277", state: "Assigned" },
    repeatWindow: "2 in 4h",
    firstSeen: "4 hr ago",
    suppressionCandidate: true,
    occurrences: [
      { id: "ALT-92782", value: "87.4%", triggered: "22 Jul 2026, 20:53", entity: "vault-cluster-eu1", breach: "+2.4% above 85%", recovered: "—", duration: "2 hr 2 min", signal: "Active" },
      { id: "ALT-92592", value: "85.8%", triggered: "22 Jul 2026, 18:24", entity: "vault-cluster-eu1", breach: "+0.8% above 85%", recovered: "19:11", duration: "47 min", signal: "Recovered" },
    ],
  },
  {
    title: "Proofpoint Message Queue Depth",
    application: "Proofpoint",
    assignment: "Email Security",
    source: "SCOM",
    severity: "Low",
    priority: "P4",
    priorityReason: "Low severity · single occurrence · no related incident",
    investigation: "New",
    owner: "Unassigned",
    repeatWindow: "1 in 24h",
    firstSeen: "2 hr ago",
    occurrences: [
      { id: "ALT-92721", value: "1,242 messages", triggered: "22 Jul 2026, 20:17", entity: "pp-gateway-04", breach: "+24% above 1,000", recovered: "20:42", duration: "25 min", signal: "Recovered" },
    ],
  },
];

const incidents = [
  { id: "INC0098421", title: "CyberArk authentication service degradation", app: "CyberArk", priority: "P2", state: "In Progress", updated: "12 min ago", assignee: "Cyber PAM Support" },
  { id: "INC0098396", title: "Intermittent VEN connectivity in GCP production", app: "Illumio", priority: "P3", state: "Investigating", updated: "48 min ago", assignee: "Network Security Ops" },
  { id: "INC0098277", title: "Vault latency above operational threshold", app: "HashiVault", priority: "P3", state: "Assigned", updated: "2 hr ago", assignee: "Secrets Platform" },
];

const Icon = ({ name }: { name: string }) => <span className={`icon icon-${name}`} aria-hidden="true" />;

export default function Home() {
  const [section, setSection] = useState("Alerts");
  const [search, setSearch] = useState("");
  const [application, setApplication] = useState("All applications");
  const [assignment, setAssignment] = useState("All assignment groups");
  const [source, setSource] = useState("All sources");
  const [expanded, setExpanded] = useState<string[]>([]);
  const [selected, setSelected] = useState<AlertGroup | null>(null);

  const filtered = useMemo(() => alerts.filter((alert) =>
    (application === "All applications" || alert.application === application) &&
    (assignment === "All assignment groups" || alert.assignment === assignment) &&
    (source === "All sources" || alert.source === source) &&
    `${alert.title} ${alert.application}`.toLowerCase().includes(search.toLowerCase())
  ), [search, application, assignment, source]);

  const toggle = (title: string) => setExpanded((current) => current.includes(title) ? current.filter((x) => x !== title) : [...current, title]);

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">C</span><div><strong>CSROCC</strong><small>Cyber Service Resilience</small></div></div>
        <div className="product-label">ALERT &amp; INCIDENT<br />INVESTIGATION</div>
        <nav>
          {["Dashboard", "Alerts", "Incidents", "Suppression"].map((item) => (
            <button key={item} onClick={() => setSection(item)} className={section === item ? "active" : ""}>
              <Icon name={item.toLowerCase()} /> {item}
              {item === "Alerts" && <span className="nav-count">11</span>}
              {item === "Incidents" && <span className="nav-count neutral">3</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom"><button><Icon name="settings" /> Settings</button><div className="profile"><div className="avatar">LA</div><div><b>Lina Analyst</b><span>Cyber Operations</span></div><span className="chevron">⌄</span></div></div>
      </aside>

      <section className="content">
        <header className="topbar"><div className="breadcrumb"><span>CSROCC</span><b>/</b> Alert &amp; Incident Investigation</div><div className="top-actions"><button className="status-dot"><i /> All systems operational</button><button className="round-button">?</button><button className="round-button">♢</button></div></header>
        {section === "Alerts" && <AlertsView filtered={filtered} search={search} setSearch={setSearch} application={application} setApplication={setApplication} assignment={assignment} setAssignment={setAssignment} source={source} setSource={setSource} expanded={expanded} toggle={toggle} setSelected={setSelected} />}
        {section === "Incidents" && <IncidentsView />}
        {section === "Dashboard" && <DashboardView onAlerts={() => setSection("Alerts")} onIncidents={() => setSection("Incidents")} />}
        {section === "Suppression" && <SuppressionView />}
      </section>
      {selected && <Workspace alert={selected} close={() => setSelected(null)} />}
    </main>
  );
}

function PageHeading({ eyebrow, title, subtitle, actions }: { eyebrow: string; title: string; subtitle: string; actions?: React.ReactNode }) {
  return <div className="page-heading"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{subtitle}</p></div>{actions && <div className="heading-actions">{actions}</div>}</div>;
}

type AlertsViewProps = {
  filtered: AlertGroup[];
  search: string;
  setSearch: (value: string) => void;
  application: string;
  setApplication: (value: string) => void;
  assignment: string;
  setAssignment: (value: string) => void;
  source: string;
  setSource: (value: string) => void;
  expanded: string[];
  toggle: (title: string) => void;
  setSelected: (alert: AlertGroup) => void;
};

function AlertsView(props: AlertsViewProps) {
  const [view, setView] = useState("All alerts");
  const [investigationState, setInvestigationState] = useState<Record<string, { investigation: AlertGroup["investigation"]; owner: string }>>({});
  const [actionMenu, setActionMenu] = useState<string | null>(null);
  const apps = ["All applications", ...Array.from(new Set(alerts.map(a => a.application)))];
  const assignments = ["All assignment groups", ...Array.from(new Set(alerts.map(a => a.assignment)))];
  const sources = ["All sources", ...Array.from(new Set(alerts.map(a => a.source)))];
  const visible = props.filtered
    .filter((alert) => {
      const current = investigationState[alert.title] || alert;
      if (view === "My alerts") return current.owner === "Lina Analyst";
      if (view === "Unassigned") return current.owner === "Unassigned";
      if (view === "Critical") return alert.severity === "Critical";
      if (view === "Repeated") return alert.occurrences.length > 1;
      if (view === "With open incident") return Boolean(alert.incident);
      if (view === "Suppression candidates") return Boolean(alert.suppressionCandidate);
      return true;
    })
    .sort((a, b) => Number(a.priority.slice(1)) - Number(b.priority.slice(1)));
  const updateAlert = (alert: AlertGroup, mode: "acknowledge" | "assign") => {
    const current = investigationState[alert.title] || { investigation: alert.investigation, owner: alert.owner };
    setInvestigationState((state) => ({ ...state, [alert.title]: mode === "acknowledge" ? { ...current, investigation: "Acknowledged" } : { investigation: current.investigation === "New" ? "Acknowledged" : current.investigation, owner: "Lina Analyst" } }));
    setActionMenu(null);
  };
  const views = ["All alerts", "My alerts", "Unassigned", "Critical", "Repeated", "With open incident", "Suppression candidates"];
  return <div className="page-wrap">
    <PageHeading eyebrow="ALERT OPERATIONS" title="Alert Overview" subtitle="Investigate and manage multi-source cyber application alerts." actions={<><button className="secondary">Export</button><button className="primary">+ Create investigation</button></>} />
    <div className="metrics compact triage-metrics">
      <Metric label="Active groups" value="3" tone="red" note="11 total occurrences" />
      <Metric label="Unacknowledged" value="2" tone="amber" note="Needs analyst action" />
      <Metric label="Priority 1" value="1" tone="red" note="Respond now" />
      <Metric label="Linked incidents" value="3" tone="blue" note="ServiceNow active" />
      <Metric label="Suppression candidates" value="1" tone="green" note="Review recommended" />
    </div>
    <div className="saved-views"><span>QUICK VIEWS</span>{views.map((item) => <button key={item} className={view === item ? "active" : ""} onClick={() => setView(item)}>{item}{item === "Unassigned" && <b>2</b>}{item === "Critical" && <b>1</b>}</button>)}</div>
    <div className="filter-panel">
      <div className="search-box"><Icon name="search" /><input value={props.search} onChange={(e) => props.setSearch(e.target.value)} placeholder="Search alert name or application..." /></div>
      <Select value={props.application} setValue={props.setApplication} values={apps} />
      <Select value={props.assignment} setValue={props.setAssignment} values={assignments} />
      <Select value={props.source} setValue={props.setSource} values={sources} />
      <button className="clear" onClick={() => { props.setSearch(""); props.setApplication(apps[0]); props.setAssignment(assignments[0]); props.setSource(sources[0]); }}>Clear</button>
    </div>
    <div className="table-card">
      <div className="table-caption"><div><b>Prioritised alert queue</b><span>{visible.length} groups · ordered by rules-based priority</span></div><button className="icon-button">↻</button></div>
      <div className="alert-grid table-header"><span>PRIORITY</span><span>ALERT</span><span>SEVERITY</span><span>APPLICATION</span><span>REPEAT PATTERN</span><span>ALERT COUNT</span><span>INVESTIGATION</span><span>INCIDENT</span><span></span></div>
      {visible.map((alert: AlertGroup) => {
        const open = props.expanded.includes(alert.title); const latest = alert.occurrences[0];
        const current = investigationState[alert.title] || { investigation: alert.investigation, owner: alert.owner };
        return <div className="alert-group" key={alert.title}>
          {alert.occurrences.slice(1, 4).map((occurrence, index) => (
            <div className={`stack-layer stack-layer-${index + 2}`} key={occurrence.id} aria-hidden="true">
              <span>{occurrence.id}</span><b>{occurrence.value}</b><small>{occurrence.triggered}</small>
            </div>
          ))}
          <div className={`alert-grid alert-row ${alert.occurrences.length > 1 ? "has-stack" : ""} ${open ? "is-expanded" : ""}`} onClick={() => props.setSelected(alert)}>
            <span className={`priority-chip ${alert.priority.toLowerCase()}`} title={alert.priorityReason}>{alert.priority}<i>ⓘ</i></span>
            <div className="alert-name"><div><b>{alert.title}</b><div className="alert-meta"><SourceBadge source={alert.source} /><span>{latest.id} · {latest.entity}</span></div></div></div>
            <span className={`severity-badge ${alert.severity.toLowerCase()}`}>{alert.severity}</span>
            <span>{alert.application}</span>
            <div className="repeat-pattern"><b>{alert.repeatWindow}</b><small>{latest.value} · {latest.triggered.split(", ")[1]}</small></div>
            <button className="alert-count-button" onClick={(e) => { e.stopPropagation(); props.toggle(alert.title); }} aria-expanded={open} aria-label={`${open ? "Collapse" : "Expand"} ${alert.occurrences.length} alert occurrences`}><b>{alert.occurrences.length}</b><span>alert{alert.occurrences.length === 1 ? "" : "s"}</span><i>{open ? "⌃" : "⌄"}</i></button>
            <div className="investigation-cell"><span className={`investigation-status ${current.investigation.toLowerCase().replaceAll(" ", "-")}`}>{current.investigation}</span><small>{current.owner}</small></div>
            {alert.incident ? <button className="incident-link" onClick={(e) => e.stopPropagation()}><b>{alert.incident.id}</b><small>{alert.incident.state}</small></button> : <button className="no-incident" onClick={(e) => e.stopPropagation()}>+ Link incident</button>}
            <div className="row-actions"><button className="workspace-button" onClick={(e) => { e.stopPropagation(); props.setSelected(alert); }} aria-label={`Open ${alert.title} workspace`}><span>Open</span>→</button><button className="more-button" onClick={(e) => { e.stopPropagation(); setActionMenu(actionMenu === alert.title ? null : alert.title); }}>•••</button>{actionMenu === alert.title && <div className="action-menu" onClick={(e) => e.stopPropagation()}><button onClick={() => updateAlert(alert, "acknowledge")}>✓ Acknowledge</button><button onClick={() => updateAlert(alert, "assign")}>👤 Assign to me</button><button onClick={() => props.setSelected(alert)}>↗ Open workspace</button><button>🔗 Link incident</button><button>⏸ Request suppression</button></div>}</div>
          </div>
          {open && <div className="occurrences">
            <div className="occurrence-head">
              <div><b>Occurrence history</b><span>First seen {alert.firstSeen} · {alert.occurrences.length} occurrences · newest first</span></div>
              <button className="open-workspace-link" onClick={() => props.setSelected(alert)}>Open full workspace <b>→</b></button>
            </div>
            <div className="occurrence-table-wrap">
              <div className="occurrence-grid occurrence-table-header">
                <span>ALERT ID</span><span>ALERT VALUE</span><span>THRESHOLD BREACH</span><span>TRIGGERED</span><span>RECOVERED</span><span>DURATION</span><span>SIGNAL STATUS</span><span>INCIDENT</span><span></span>
              </div>
              {alert.occurrences.map((o, index) => <div className="occurrence-grid occurrence-row" key={o.id}>
                <div className="occurrence-id"><span className="history-dot" /><b>{o.id}</b>{index === 0 && <em>Latest</em>}</div>
                <strong>{o.value}</strong>
                <span className="breach-value">{o.breach}</span>
                <span>{o.triggered}</span>
                <span>{o.recovered}</span><span>{o.duration}</span>
                <span className={`signal-status ${o.signal.toLowerCase()}`}>{o.signal}</span>
                <span>{alert.incident?.id || "—"}</span>
                <button onClick={() => props.setSelected(alert)}>View →</button>
              </div>)}
            </div>
          </div>}
        </div>;
      })}
      {!visible.length && <div className="empty">No alert groups match this view and filter combination.</div>}
    </div>
  </div>;
}

function Select({ value, setValue, values }: { value: string; setValue: (v: string) => void; values: string[] }) { return <select value={value} onChange={(e) => setValue(e.target.value)}>{values.map((v) => <option key={v}>{v}</option>)}</select>; }

function SourceBadge({ source }: { source: string }) { const letters: Record<string,string> = { CyberSplunk: "CS", ITSI: "IT", AppDynamics: "AD", SCOM: "SC" }; return <div className="source-badge"><i className={`source-icon ${source.toLowerCase()}`}>{letters[source]}</i><span>{source}</span></div>; }

function Metric({ label, value, note, tone }: { label: string; value: string; note: string; tone: string }) { return <article className="metric"><span>{label}</span><div><strong>{value}</strong><i className={tone} /></div><small>{note}</small></article>; }

function DashboardView({ onAlerts, onIncidents }: { onAlerts: () => void; onIncidents: () => void }) { return <div className="page-wrap"><PageHeading eyebrow="CYBER OPERATIONS" title="Investigation Dashboard" subtitle="A consolidated view of active alerts and cyber incidents." /><div className="metrics"><Metric label="Alert groups" value="4" tone="red" note="11 total occurrences" /><Metric label="Open incidents" value="3" tone="blue" note="1 priority two" /><Metric label="Needs triage" value="2" tone="amber" note="Oldest: 48 minutes" /><Metric label="Noise reduction" value="62%" tone="green" note="Last 30 days" /></div><div className="dashboard-grid"><div className="summary-card"><div className="card-title"><div><b>Operational workload</b><span>Current items requiring analyst action</span></div><button>Last 24 hours⌄</button></div><div className="bar-chart"><div style={{height:"42%"}}><span>6</span><i /></div><div style={{height:"72%"}}><span>11</span><i /></div><div style={{height:"58%"}}><span>9</span><i /></div><div style={{height:"91%"}}><span>14</span><i /></div><div style={{height:"66%"}}><span>10</span><i /></div><div style={{height:"78%"}}><span>12</span><i /></div></div><div className="chart-labels"><span>12am</span><span>4am</span><span>8am</span><span>12pm</span><span>4pm</span><span>Now</span></div></div><div className="quick-card"><b>Start investigating</b><p>Move directly to the operational queue that needs attention.</p><button onClick={onAlerts}><span className="quick-icon red">!</span><div><b>Alert investigation</b><small>4 active groups</small></div><span>→</span></button><button onClick={onIncidents}><span className="quick-icon black">IN</span><div><b>Incident investigation</b><small>3 open incidents</small></div><span>→</span></button></div></div></div>; }

function IncidentsView() { return <div className="page-wrap"><PageHeading eyebrow="SERVICENOW" title="Cyber Incident View" subtitle="Review and investigate cyber incidents from ServiceNow." actions={<button className="primary">+ Link incident</button>} /><div className="filter-panel"><div className="search-box"><Icon name="search" /><input placeholder="Search incident, application or assignee..." /></div><select><option>All priorities</option></select><select><option>All states</option></select><select><option>All assignment groups</option></select></div><div className="incident-list">{incidents.map((x) => <article key={x.id}><div className={`priority ${x.priority.toLowerCase()}`}>{x.priority}</div><div className="incident-main"><span>{x.id}</span><b>{x.title}</b><small>{x.app} · {x.assignee}</small></div><span className="state">{x.state}</span><span className="updated">Updated {x.updated}</span><button>Open →</button></article>)}</div></div>; }

function SuppressionView() { return <div className="page-wrap"><PageHeading eyebrow="GUIDED WORKFLOW" title="Alert Suppression" subtitle="Create controlled suppression changes with governance checkpoints." actions={<button className="primary">Start suppression request</button>} /><div className="workflow"><div className="workflow-bar">{["Define request", "AI review", "Jira evidence", "Create PR", "SME approval", "Deploy"].map((x, i) => <div key={x} className={i < 2 ? "done" : i === 2 ? "current" : ""}><span>{i < 2 ? "✓" : i + 1}</span><b>{x}</b></div>)}</div><div className="workflow-content"><span className="eyebrow">STEP 3 OF 6</span><h2>Attach governance evidence</h2><p>Link the approved Jira request before the platform creates a configuration pull request.</p><label>Jira ticket<input placeholder="e.g. CYBER-1842" /></label><label>Suppression reason<textarea placeholder="Describe why this alert is confirmed as non-actionable..." /></label><div className="ai-note"><b>AI validation</b><span>The alert definition and proposed suppression window will be checked before the next step.</span></div><button className="primary">Validate and continue →</button></div></div></div>; }

function Workspace({ alert, close }: { alert: AlertGroup; close: () => void }) {
  const [tab, setTab] = useState("Investigation");
  const latest = alert.occurrences[0];
  return <div className="workspace-page">
    <header className="workspace-topbar"><button className="back-button" onClick={close} aria-label="Back to Alert Overview">←</button><div><span className="back-label">BACK TO ALERT OVERVIEW</span><div className="workspace-breadcrumb">Alert &amp; Incident Investigation <b>/</b> Alert Workspace</div></div><div className="workspace-top-actions"><button className="secondary">Link incident</button><button className="primary">Acknowledge alert</button></div></header>
    <main className="workspace"><section className="workspace-hero"><div><span className="eyebrow">ALERT WORKSPACE</span><h1>{alert.title}</h1><p>{latest.id} · {alert.application} · {alert.source}</p></div><div className="workspace-status"><span className={`priority-chip ${alert.priority.toLowerCase()}`}>{alert.priority}</span><span className={`severity-badge ${alert.severity.toLowerCase()}`}>{alert.severity}</span><span className="state">{alert.investigation}</span><b>{alert.occurrences.length} occurrences</b></div></section>
      <nav>{["Investigation", "History", "Activity"].map(x => <button className={tab === x ? "active" : ""} onClick={() => setTab(x)} key={x}>{x}</button>)}</nav>
      {tab === "Investigation" && <div className="workspace-body"><section className="facts"><div><span>Latest value</span><b>{latest.value}</b></div><div><span>Triggered</span><b>{latest.triggered}</b></div><div><span>Affected entity</span><b>{latest.entity}</b></div><div><span>Assignment group</span><b>{alert.assignment}</b></div></section><section className="analysis"><div className="analysis-title"><span className="ai-star">✦</span><div><b>AI-assisted analysis</b><small>Uses alert configuration and approved knowledge</small></div><button>Regenerate</button></div><h3>Initial assessment</h3><p>The latest occurrence is part of a recurring pattern. {alert.occurrences.length} matching alerts were observed for the same KPI. Confirm application health before treating this as alert noise.</p><h3>Recommended checks</h3><ol><li>Confirm the affected entity is reachable and reporting current telemetry.</li><li>Compare the latest value against the configured critical threshold.</li><li>Review related incidents and recent platform changes.</li></ol></section><div className="workspace-actions"><button className="secondary">Link incident</button><button className="secondary">Start suppression</button><button className="primary">Acknowledge alert</button></div></div>}
      {tab === "History" && <div className="workspace-body"><div className="history-list">{alert.occurrences.map((o, i) => <div key={o.id}><span className="history-dot" /><div><b>{o.value}</b><small>{o.id} · {o.entity}</small></div><span>{o.triggered}</span>{i === 0 && <em>Latest</em>}</div>)}</div></div>}
      {tab === "Activity" && <div className="workspace-body"><div className="activity-empty"><span>◎</span><b>No analyst activity yet</b><p>Acknowledgements, comments and linked incidents will appear here.</p></div></div>}
    </main>
  </div>;
}
