# Alert & Incident Investigation MVP

Interactive frontend MVP for a CSROCC capability that consolidates multi-source cyber application alerts and ServiceNow incidents.

## Included

- Duplicate alert grouping by alert name
- Latest occurrence shown in the overview with occurrence count
- Hover stack treatment and expandable occurrence history
- Filters for application, assignment group, and alert source
- Multi-source badges for CyberSplunk, ITSI, AppDynamics, and SCOM
- Alert investigation workspace with history and AI-assisted analysis mock-up
- Cyber incident view using ServiceNow-style mock data
- Guided alert suppression workflow mock-up
- Responsive desktop and tablet layout

All data is mock data in `app/page.tsx`. No backend, authentication, ServiceNow, or alert-source APIs are connected in this MVP.

## Run locally

Requires Node.js 22.13 or later.

```bash
npm install
npm run dev
```

Open the local URL printed by the development server.

## Production build

```bash
npm run build
```

## Main files

- `app/page.tsx` — mock data, application views, and UI interactions
- `app/globals.css` — full visual system and responsive styling
- `app/layout.tsx` — metadata and application shell

## Production integration notes

The current duplicate grouping rule assumes an alert name uniquely identifies an application KPI. Before connecting live sources, normalize alert records into a common schema and preserve each source's native alert ID, occurrence timestamp, value, entity, assignment group, and correlation metadata.
