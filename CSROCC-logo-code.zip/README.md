# CSROCC Logo

Production-ready vector version of the approved CSROCC wordmark.

**Full name:** Cyber Service Resilience Operations Command Center

## Files

- `csrocc-logo-dark.svg` — white wordmark for the login page and other dark-blue backgrounds.
- `csrocc-logo-light.svg` — navy wordmark with a blue detached point for white or light backgrounds.
- `CsroccLogo.tsx` — React wrapper that selects the correct SVG.
- `preview.html` — local visual comparison of the two variants.

All visible lettering in the two production SVGs is converted to vector paths.
They do not rely on a font being installed.

## React

```tsx
import { CsroccLogo } from "./csrocc-logo/CsroccLogo";

<CsroccLogo
  variant="dark"
  style={{ width: 420, height: "auto" }}
/>
```

Use `variant="dark"` on navy/blue backgrounds and `variant="light"` on white
or very light backgrounds.

## HTML

```html
<img
  src="/assets/csrocc-logo-dark.svg"
  alt="CSROCC — Cyber Service Resilience Operations Command Center"
  width="420"
/>
```

Do not stretch the SVG, change the wordmark spacing, add glow effects, or move
the detached point. Keep clear space around the mark equal to at least half the
height of the first `C`.
