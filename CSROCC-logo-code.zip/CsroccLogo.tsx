import type { ImgHTMLAttributes } from "react";
import darkLogo from "./csrocc-logo-dark.svg";
import lightLogo from "./csrocc-logo-light.svg";

type CsroccLogoProps = Omit<
  ImgHTMLAttributes<HTMLImageElement>,
  "src" | "alt"
> & {
  /** Use "dark" on the platform's blue background and "light" on white. */
  variant?: "dark" | "light";
  alt?: string;
};

/**
 * CSROCC production wordmark.
 *
 * The imported SVGs use outlined vector paths, so the logo does not depend
 * on a browser font and remains consistent across environments.
 */
export function CsroccLogo({
  variant = "dark",
  alt = "CSROCC — Cyber Service Resilience Operations Command Center",
  ...props
}: CsroccLogoProps) {
  return (
    <img
      src={variant === "dark" ? darkLogo : lightLogo}
      alt={alt}
      {...props}
    />
  );
}
